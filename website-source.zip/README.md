# Knowledge BBDD

Sitio estático preparado para GitHub Pages. La portada contiene seis áreas:
MongoDB, SQL Server, MySQL, AWS RDS, Atlas e IaC. SQL Server reúne las 115 URL
distintas del sitio de origen, agrupadas por tema y con búsqueda en el navegador.

## Publicación

Sube **el contenido de esta carpeta** a la raíz de un repositorio. En GitHub,
abre **Settings → Pages → Build and deployment**, elige **Deploy from a branch**,
selecciona la rama y la carpeta **/(root)** y guarda. El archivo `.nojekyll`
permite publicar el HTML tal como está. Los enlaces internos son relativos y
funcionan también si el sitio se publica bajo `/nombre-del-repositorio/`.

Para una prueba local, ejecuta `python -m http.server 8000` dentro de esta
carpeta y abre `http://localhost:8000/`. El buscador requiere servir los
archivos por HTTP; al abrir `index.html` directamente desde el disco puede
quedar bloqueado por el navegador.

## Contenido y actualización

Las cinco áreas restantes están preparadas y señalan que aún no tienen
contenido. Cada artículo de SQL Server enlaza a su página de origen. Algunas
páginas contienen carpetas externas incrustadas que dependen de Google Drive.

El HTML original descargado se conserva aparte en `knowledge-bbdd-html.zip`.
Para regenerar esta web, coloca la carpeta extraída `knowledge-bbdd-html` junto
a `build_knowledge_site.py`, instala `beautifulsoup4` y ejecuta el script.
